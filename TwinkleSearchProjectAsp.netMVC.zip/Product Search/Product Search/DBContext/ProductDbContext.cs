﻿using Microsoft.EntityFrameworkCore;

namespace Product_Search.DBContext
{
    public class ProductDbContext : DbContext
    {
        public ProductDbContext(DbContextOptions options):base(options)
        {
        }
        public DbSet<Product> Products { get; set;}
        public List<Product> SearchProducts(string productName, string size, string category, string SearchConj)
        {
            return Products.FromSqlRaw("EXEC SearchProducts @p0, @p1, @p2, @p3", productName, size, category, SearchConj).ToList();
        }
        public List<Product> LoadProduct()
        {
            return Products.FromSqlRaw("EXEC LoadAllProduct").ToList();
        }
    }
}
