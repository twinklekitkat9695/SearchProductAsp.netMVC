﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.Data.SqlClient;
using Product_Search.DBContext;
using System.Collections.Generic;
using System.Drawing;

namespace Product_Search.Controllers
{
    public class ProductController : Controller
    {
        private readonly ProductDbContext _context;

        public ProductController(ProductDbContext context)
        {
            _context = context;
        }
        public ActionResult Index()
        {
            List<Product> allProducts = _context.LoadProduct();
            //List<Product_Search.DBContext.Product> productList = allProducts.ToList();
            //List<Product> productList = allProducts.Select(product => new Product
            //{
            //    // Map properties from Product_Search.DBContext.Product to Product
            //    ProductName = product.ProductName, // Replace with actual property names
            //    Size = product.Size,
            //    Price = product.Price,
            //    MfgDate = product.MfgDate,
            //    Category = product.Category,
            //    // Add other properties as needed
            //}).ToList();
            return View(allProducts);
        }


        [HttpPost]
        public ActionResult Search(string productName, string size, string category, string SearchConj)
        {
            List<Product> products = _context.SearchProducts(productName, size, category, SearchConj);
            //List<Product_Search.DBContext.Product> productList = products.ToList();
            //List<Product> productList = products.Select(product => new Product
            //{
            //    // Map properties from Product_Search.DBContext.Product to Product
            //    ProductName = product.ProductName, // Replace with actual property names
            //    Size = product.Size,
            //    Price = product.Price,
            //    MfgDate = product.MfgDate,
            //    Category = product.Category,
            //    // Add other properties as needed
            //}).ToList();
            return PartialView("_SearchResults", products);
        }
    }

    }
