﻿
    $(document).ready(function () {
        $('#searchButton').on('click', function (e) {
            e.preventDefault(); // Prevent the form from submitting

            // Extract form data
            var formData = $('#searchForm').serialize();

            // Perform an AJAX request to fetch search results
            $.ajax({
                type: 'POST',
                url: '/Product/Search',
                data: formData,
                success: function (data) {
                    $('#searchResults').html(data);
                }
            });
        });

        $('#resetButton').on('click', function () {
            // Reset the form fields
            $('#searchForm')[0].reset();
        });
    });

